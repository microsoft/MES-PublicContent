<#
.SYNOPSIS
Interactive assistant to compare an existing configuration file with the current model (Models.ps1)
and (optionally) extend / update the model by asking the user for metadata.

.NEW FEATURES (Aug 2025)
- Ignores the top-level "SolutionMetadata" section (and its children) when scanning config.
- Captures & embeds the configuration file JSON version (tries SolutionMetadata.JsonVersion, JsonVersion, or Version)
  into the generated model region as a comment plus a variable: $ConfigJsonVersion
- Unified Diff View:
    * Shows both:
        - Config paths NOT in the model (UnmappedPaths)
        - Model question ConfigurationCodes NOT found in the config (OrphanModelPaths)
      in one consolidated display (console and optional file).
- Preview of proposed model changes BEFORE writing (automatic diff preview for both InPlace and new file).
- Explicit confirmation prompt before saving (unless -Force).
- Backup of original model ALWAYS when using -InPlace (timestamped), even if an earlier backup exists.
- Dry-run / Diff-only modes (no generation, just diff output).
- NonInteractive mode still supported.
- Supports optional Markdown diff output.

.PARAMETER ConfigPath
Path to the configuration JSON to analyze.

.PARAMETER BaseModelPath
Path to existing Models.ps1 (default: sibling Models.ps1).

.PARAMETER OutputModelPath
Destination path for new / augmented model script (ignored if -InPlace unless explicitly provided).

.PARAMETER InPlace
Append generated region directly to BaseModelPath (after a backup is created).

.PARAMETER NonInteractive
Auto-generate stub questions for unmapped paths (no prompts).

.PARAMETER DiffOnly
Only display the model/config diff (unmapped vs orphan) then exit.

.PARAMETER Preview
Show diff & proposed generated section blocks without writing (implies no save). (If combined with InPlace, InPlace ignored.)

.PARAMETER Force
Skip confirmation prompt on save.

.PARAMETER NewSectionPrefix
Prefix for auto-generated new section codes (default: AutoSec).

.PARAMETER AutoSectionTitle
Title used for auto-generated sections (default: "Auto Generated Section").

.PARAMETER MaxQuestionsPerAutoSection
Max questions per auto-generated section in NonInteractive mode (default: 40).

.PARAMETER DiffOutputPath
Optional path to write a Markdown diff/report (Unified model-config mapping view).

.EXAMPLE
pwsh .\CompareModelAndConfig.ps1 -ConfigPath .\Config\CollectExchSecConfiguration.json -DiffOnly

.EXAMPLE
pwsh .\CompareModelAndConfig.ps1 -ConfigPath config.json -NonInteractive -InPlace -Force

.EXAMPLE
pwsh .\CompareModelAndConfig.ps1 -ConfigPath config.json -Preview -DiffOutputPath .\ModelConfigDiff.md

.NOTES
Unmapped path enumeration now ignores the entire 'SolutionMetadata' branch.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string]$ConfigPath,
    [string]$BaseModelPath = (Join-Path $PSScriptRoot 'Models.ps1'),
    [string]$OutputModelPath,
    [switch]$InPlace,
    [switch]$NonInteractive,
    [switch]$DiffOnly,
    [switch]$Preview,
    [switch]$Force,
    [string]$NewSectionPrefix = 'AutoSec',
    [string]$AutoSectionTitle = 'Auto Generated Section',
    [int]$MaxQuestionsPerAutoSection = 40,
    [string]$DiffOutputPath
)

Set-StrictMode -Version Latest

function Fail($m){ throw $m }

if (-not (Test-Path -LiteralPath $BaseModelPath)) { Fail "Models file not found: $BaseModelPath" }
if (-not (Test-Path -LiteralPath $ConfigPath)) { Fail "Config file not found: $ConfigPath" }

Write-Host "Loading model from: $BaseModelPath"
. $BaseModelPath

if (-not (Get-Command Build-SetupConfiguration -ErrorAction SilentlyContinue)) {
    Fail "Build-SetupConfiguration was not defined in $BaseModelPath."
}

$existingSections = Build-SetupConfiguration
if (-not $existingSections) { Fail "No sections returned by Build-SetupConfiguration." }

# Build set of existing model configuration codes
$existingCodes = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
foreach ($s in $existingSections) {
    foreach ($q in $s.Collection) {
        if ($q.ConfigurationCode) { $null = $existingCodes.Add($q.ConfigurationCode) }
    }
    foreach ($sub in $s.Section) {
        foreach ($q in $sub.Collection) {
            if ($q.ConfigurationCode) { $null = $existingCodes.Add($q.ConfigurationCode) }
        }
    }
}

# Load configuration JSON
Write-Host "Loading configuration JSON: $ConfigPath"
try {
    $jsonContent = Get-Content -LiteralPath $ConfigPath -Raw
    $configObj = $jsonContent | ConvertFrom-Json -Depth 80
} catch {
    Fail "Failed to parse config JSON: $($_.Exception.Message)"
}

# Extract a JSON version reference (best-effort)
$ConfigJsonVersion = $null
if ($configObj.PSObject.Properties.Name -contains 'SolutionMetadata') {
    $meta = $configObj.SolutionMetadata
    foreach ($cand in 'JsonVersion','JSONVersion','Version','SchemaVersion') {
        if ($meta -and $meta.PSObject.Properties.Name -contains $cand) {
            $ConfigJsonVersion = [string]$meta.$cand
            break
        }
    }
}
if (-not $ConfigJsonVersion) {
    foreach ($cand in 'JsonVersion','JSONVersion','Version','SchemaVersion') {
        if ($configObj.PSObject.Properties.Name -contains $cand) {
            $ConfigJsonVersion = [string]$configObj.$cand
            break
        }
    }
}
if (-not $ConfigJsonVersion) { $ConfigJsonVersion = '<unknown>' }

# Enumerate paths (skip SolutionMetadata entirely)
$allPaths = New-Object System.Collections.Generic.List[string]

function Add-LeafPath {
    param($path)
    if ([string]::IsNullOrWhiteSpace($path)) { return }
    if (-not $allPaths.Contains($path)) { $allPaths.Add($path) }
}

function Recurse-Config {
    param(
        $Node,
        [string]$Prefix
    )
    if ($Prefix -eq 'SolutionMetadata' -or $Prefix -like 'SolutionMetadata.*') {
        return  # ignore entire branch
    }
    if ($Node -is [psobject]) {
        foreach ($prop in $Node.PSObject.Properties) {
            $name = $prop.Name
            $val  = $prop.Value
            $path = if ($Prefix) { "$Prefix.$name" } else { $name }
            if ($val -is [psobject]) {
                Recurse-Config -Node $val -Prefix $path
            } elseif ($val -is [System.Collections.IEnumerable] -and $val -isnot [string]) {
                # Detect array of primitives => treat as a leaf
                $primitiveArray = $true
                foreach ($it in $val) {
                    if ($it -is [psobject]) { $primitiveArray = $false; break }
                }
                if ($primitiveArray) {
                    Add-LeafPath $path
                } else {
                    Recurse-Config -Node $val -Prefix $path
                }
            } else {
                Add-LeafPath $path
            }
        }
    } elseif ($Node -is [System.Collections.IEnumerable] -and $Node -isnot [string]) {
        $i=0
        foreach ($item in $Node) {
            Recurse-Config -Node $item -Prefix "$Prefix[$i]"
            $i++
        }
    }
}

Recurse-Config -Node $configObj -Prefix ''

# Identify unmapped config paths (present in config but missing in model)
$unmappedConfigPaths = $allPaths | Where-Object { -not $existingCodes.Contains($_) } | Sort-Object

# Identify orphaned model paths (in model but not present in config)
$orphanModelPaths = $existingCodes | Where-Object { -not $allPaths.Contains($_) } | Sort-Object

Write-Host "--------------------------------------------------"
Write-Host "Config paths (excluding SolutionMetadata) total : $($allPaths.Count)"
Write-Host "Unmapped config paths (need questions)          : $($unmappedConfigPaths.Count)"
Write-Host "Model paths NOT found in config (orphans)       : $($orphanModelPaths.Count)"
Write-Host "Config JSON Version detected                    : $ConfigJsonVersion"
Write-Host "--------------------------------------------------"

# Combined diff rendering
function Show-CombinedDiff {
    param([switch]$ReturnString)

    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine("### Model vs Config Diff")
    [void]$sb.AppendLine()
    [void]$sb.AppendLine("Config JSON Version: ` $ConfigJsonVersion` ")
    [void]$sb.AppendLine()
    [void]$sb.AppendLine("#### Unmapped Config Paths (need addition)")
    if ($unmappedConfigPaths.Count -eq 0) {
        [void]$sb.AppendLine("_None_")
    } else {
        foreach ($p in $unmappedConfigPaths) {
            [void]$sb.AppendLine("- `+$p` ")
        }
    }
    [void]$sb.AppendLine()
    [void]$sb.AppendLine("#### Orphan Model Paths (present in model, missing in config)")
    if ($orphanModelPaths.Count -eq 0) {
        [void]$sb.AppendLine("_None_")
    } else {
        foreach ($p in $orphanModelPaths) {
            [void]$sb.AppendLine("- `-$p` ")
        }
    }
    [void]$sb.AppendLine()
    if ($ReturnString) { return $sb.ToString() } else { Write-Host $sb.ToString() }
}

Show-CombinedDiff
if ($DiffOutputPath) {
    $diffContent = Show-CombinedDiff -ReturnString
    Set-Content -LiteralPath $DiffOutputPath -Value $diffContent -Encoding UTF8
    Write-Host "Diff written to: $DiffOutputPath"
}

if ($DiffOnly) {
    Write-Host "DiffOnly specified. Exiting."
    return
}

if ($unmappedConfigPaths.Count -eq 0) {
    Write-Host "No unmapped config paths. Nothing to generate."
    if ($Preview) { Write-Host "Preview ended (no changes)." }
    return
}

# --- Generation Preparation ---

$generatedSections = [ordered]@{}  # sectionCode -> [ordered] meta with Questions[]
function Safe-SuggestCode($path) {
    $seg = ($path -split '\.')[-1]
    $seg = $seg -replace '[^A-Za-z0-9]',''
    if (-not $seg) { $seg = 'Q' + ([guid]::NewGuid().ToString('N').Substring(0,6)) }
    return $seg
}
function Fetch-Value($path) {
    $parts = $path.Split('.')
    $cursor = $configObj
    foreach ($p in $parts) {
        if ($cursor -isnot [psobject]) { return $null }
        if ($cursor.PSObject.Properties.Name -notcontains $p) { return $null }
        $cursor = $cursor.$p
    }
    return $cursor
}
function New-AutoSection {
    param([int]$IndexSeed)
    $code = "{0}{1}" -f $NewSectionPrefix,$IndexSeed
    $title = "$AutoSectionTitle $IndexSeed"
    [ordered]@{
        Code=$code
        Title=$title
        Index=(500 + $IndexSeed)   # base offset to avoid collisions
        Description="Auto-generated section $IndexSeed."
        Condition=$null
        Questions=@()
    }
}

$autoSectionCounter = 0
$currentAutoSectionCode = $null
$currentAutoQuestions = 0

$quitAll = $false
$skipRemaining = $false

# Interactive enumeration
foreach ($path in $unmappedConfigPaths) {
    if ($quitAll -or $skipRemaining) { break }

    $rawVal = Fetch-Value $path
    $isArray = ($rawVal -is [System.Collections.IEnumerable] -and $rawVal -isnot [string])
    $valueStr = if ($isArray) { ($rawVal | ForEach-Object { $_ }) -join ';' } else { "$rawVal" }

    if ($NonInteractive) {
        if (-not $currentAutoSectionCode -or $currentAutoQuestions -ge $MaxQuestionsPerAutoSection) {
            $autoSectionCounter++
            $secMeta = New-AutoSection -IndexSeed $autoSectionCounter
            $generatedSections[$secMeta.Code] = $secMeta
            $currentAutoSectionCode = $secMeta.Code
            $currentAutoQuestions = 0
        }
        $currentAutoQuestions++
        $qCode = Safe-SuggestCode $path
        $valType = if ($isArray) { 'Array' } else { '' }
        $valTypeSwitch = if ($valType) { "-ValueType `"$valType`"" } else { '' }
        $secRefVar = '$secRef_' + $currentAutoSectionCode
        $questionBlock = @"
# Auto-generated (non-interactive) for path: $path
`$secRef.Collection.Add( (New-SetupQuestion -Code "$qCode" -Index $currentAutoQuestions -ConfigurationCode "$path" `
    -Question "$path ?" -Description "" -Value "$valueStr" $valTypeSwitch ) )
"@
        $generatedSections[$currentAutoSectionCode].Questions += $questionBlock
        continue
    }

    Write-Host ""
    Write-Host "Unmapped Path : $path"
    Write-Host "Current Value : $valueStr"
    $choice = Read-Host "[A]dd / [S]kip / s[K]ip remaining / [Q]uit"
    switch ($choice.ToUpper()) {
        'Q' { $quitAll=$true; break }
        'K' { $skipRemaining=$true; continue }
        'S' { continue }
        'A' { }  # proceed
        default { continue }
    }

    # Choose an existing generated section or create new
    $existingSectionCodes = ($generatedSections.Keys + ($existingSections | ForEach-Object Code)) | Sort-Object -Unique
    Write-Host "Existing Section Codes: $([string]::Join(', ',$existingSectionCodes))"
    $secChoice = Read-Host "Enter target section code (blank = create new auto section)"

    if (-not $secChoice) {
        $autoSectionCounter++
        $secMeta = New-AutoSection -IndexSeed $autoSectionCounter
        $generatedSections[$secMeta.Code] = $secMeta
        $secChoice = $secMeta.Code
    } else {
        if (-not $generatedSections.ContainsKey($secChoice)) {
            # If not already in generated map but is an existing model section, create extension placeholder
            if (($existingSections | ForEach-Object Code) -contains $secChoice) {
                $generatedSections[$secChoice] = [ordered]@{
                    Code=$secChoice
                    Title=$secChoice
                    Index=999
                    Description="(Extended section)"
                    Condition=$null
                    Questions=@()
                }
            } else {
                # create new manual meta
                $title = Read-Host "New Section Title (default=$secChoice)"
                if (-not $title) { $title = $secChoice }
                $desc  = Read-Host "New Section Description"
                $idx   = Read-Host "Section Index (int)"; if (-not [int]::TryParse($idx,[ref]0)) { $idx = (600 + $autoSectionCounter) }
                $cond  = Read-Host "Section Condition (optional)"
                $generatedSections[$secChoice] = [ordered]@{
                    Code=$secChoice
                    Title=$title
                    Index=[int]$idx
                    Description=$desc
                    Condition=$cond
                    Questions=@()
                }
            }
        }
    }

    $targetSection = $generatedSections[$secChoice]

    $suggestCode = Safe-SuggestCode $path
    $qCode = Read-Host "Question Code (default=$suggestCode)"
    if (-not $qCode) { $qCode = $suggestCode }

    $qText = Read-Host "Question Text (default: $path ?)"
    if (-not $qText) { $qText = "$path ?" }

    $qDesc = Read-Host "Description (optional)"
    $qCond = Read-Host "Condition (optional)"
    $qPoss = Read-Host "Possible values (comma, optional)"
    $qHidden = Read-Host "Hidden? (Y/N default=N)"
    $hiddenSwitch = if ($qHidden -and $qHidden.ToUpper().StartsWith('Y')) { '-Hidden' } else { '' }
    $pvArray = @()
    if ($qPoss) { $pvArray = $qPoss.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ } }
    $valType = if ($isArray) { 'Array' } elseif ($path -match 'Password|Secret|Token|Key$') { 'SecureString' } else { '' }
    $valTypeSwitch = if ($valType) { "-ValueType `"$valType`"" } else { '' }

    $questionBlock = @"
# Auto-generated for path: $path
`$secRef.Collection.Add( (New-SetupQuestion -Code "$qCode" -Index $([int]($targetSection.Questions.Count+1)) -ConfigurationCode "$path" `
    -Question "$qText" `
    -Description "$qDesc" `
    $( if ($pvArray) { "-PossibleValues @(`"$([string]::Join('","',$pvArray))`")" } ) `
    $( if ($qCond) { "-Condition `"$qCond`"" } ) `
    -Value "$valueStr" $hiddenSwitch $valTypeSwitch ) )
"@
    $targetSection.Questions += $questionBlock
}

if ($Preview) {
    Write-Host "`nPreview mode: Showing diff & proposed generated sections. No file changes will be made."
}

if ($generatedSections.Keys.Count -eq 0) {
    Write-Host "No new sections/questions generated."
    if ($Preview) { return }
    if ($InPlace) { Write-Host "Nothing to append in-place." }
    return
}

# -------------------- Compose Generated Block --------------------
$genHeader = "# ===== AUTO-GENERATED MODEL EXTENSIONS (BEGIN) ====="
$genFooter = "# ===== AUTO-GENERATED MODEL EXTENSIONS (END) ====="

$originalModel = Get-Content -LiteralPath $BaseModelPath -Raw
$proposed = New-Object System.Text.StringBuilder
[void]$proposed.AppendLine($genHeader)
[void]$proposed.AppendLine("# Generated: $(Get-Date -Format o)")
[void]$proposed.AppendLine("# Source Config: $ConfigPath")
[void]$proposed.AppendLine("# Config JSON Version: $ConfigJsonVersion")
[void]$proposed.AppendLine("")
[void]$proposed.AppendLine("# Reference variable (optional use):")
[void]$proposed.AppendLine("$" + "ConfigJsonVersion = '$ConfigJsonVersion'")
[void]$proposed.AppendLine("")

foreach ($secCode in $generatedSections.Keys) {
    $meta = $generatedSections[$secCode]
    $questions = $meta.Questions
    # Detect if original model has this section code defined
    $exists = ($existingSections | Where-Object Code -eq $meta.Code)
    if (-not $exists) {
@"
# New Section: $($meta.Code)
`$secRef = New-SetupSection -Code `"$($meta.Code)`" -Title `"$($meta.Title)`" -Index $($meta.Index) -Description `"$($meta.Description)`" $( if ($meta.Condition) { "-Condition `"$($meta.Condition)`"" } )

"@ | ForEach-Object { [void]$proposed.AppendLine($_) }
        foreach ($qBlock in $questions) { [void]$proposed.AppendLine($qBlock) }
        [void]$proposed.AppendLine("`$SetupConfiguration.Add(`$secRef)")
        [void]$proposed.AppendLine()
    } else {
@"
# Extending existing section: $($meta.Code)
`$secRef = (`$SetupConfiguration | Where-Object Code -eq `"$($meta.Code)`")
if (-not `$secRef) {
    # Fallback create (should not normally happen)
    `$secRef = New-SetupSection -Code `"$($meta.Code)`" -Title `"$($meta.Title)`" -Index $($meta.Index) -Description `"$($meta.Description)`"
    `$SetupConfiguration.Add(`$secRef)
}

"@ | ForEach-Object { [void]$proposed.AppendLine($_) }
        foreach ($qBlock in $questions) { [void]$proposed.AppendLine($qBlock) }
        [void]$proposed.AppendLine()
    }
}

[void]$proposed.AppendLine($genFooter)

# Show proposed (preview)
Write-Host "`n================ Proposed Model Extension Region (BEGIN) ================"
Write-Host $proposed.ToString()
Write-Host "================ Proposed Model Extension Region (END) ================`n"

if ($Preview) {
    Write-Host "Preview requested; not writing any file."
    return
}

# Determine output target
if (-not $OutputModelPath) {
    if ($InPlace) {
        $OutputModelPath = $BaseModelPath
    } else {
        $OutputModelPath = Join-Path (Split-Path -Parent $BaseModelPath) 'Models.Custom.generated.ps1'
    }
}

# Compose full content
if ($InPlace) {
    # Always make a backup even if Force used
    $backup = "$BaseModelPath.bak.$((Get-Date).ToString('yyyyMMddHHmmss'))"
    Copy-Item -LiteralPath $BaseModelPath -Destination $backup -Force
    Write-Host "In-place update selected. Backup created: $backup"
    $newContent = ($originalModel.TrimEnd() + "`r`n`r`n" + $proposed.ToString())
} else {
    if (Test-Path -LiteralPath $OutputModelPath) {
        Write-Host "Target output exists: $OutputModelPath"
        if (-not $Force) {
            $resp = Read-Host "Overwrite existing output? (Y/N)"
            if ($resp.ToUpper() -ne 'Y') {
                Write-Host "Aborted by user."
                return
            }
        }
    }
    $newContent = ($originalModel.TrimEnd() + "`r`n`r`n" + $proposed.ToString())
}

if (-not $Force) {
    $confirm = Read-Host "Proceed to write changes to '$OutputModelPath'? (Y/N)"
    if ($confirm.ToUpper() -ne 'Y') {
        Write-Host "Aborted."
        return
    }
}

Set-Content -LiteralPath $OutputModelPath -Value $newContent -Encoding UTF8
Write-Host "Model written: $OutputModelPath"
Write-Host "Sections added/extended: $([string]::Join(', ',$generatedSections.Keys))"
Write-Host "Done."