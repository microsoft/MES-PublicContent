<#
Models.Common.ps1
UPDATE (Wizard refactor):
 - Moved WizardSectionCode from (previous) SetupQuestion usage to SetupSection.
 - Rationale: Wizard is conceptually tied to a subsection (e.g. EntraIDApplicationInformation, DCRInformation)
   rather than an individual controlling question. Any question inside a subsection marked with
   WizardSectionCode will now surface a Wizard... button (logic handled in UI.Sections.ps1).
 - No change required for serialization / validation.
#>

class SetupQuestion {
    [string]$SectionCode
    [string]$Code
    [int]$Index
    [string]$Question
    [string]$Description
    [string[]]$PossibleValues
    [string]$ConfigurationCode
    [string]$Condition
    [object]$Value
    [object]$OriginalValue
    [string]$ValueType
    [string]$Regex
    [string]$ValidationHookFunction
    [bool]$Hidden
    [bool]$IsArray
    [System.Collections.ArrayList]$ArrayItems = [System.Collections.ArrayList]::new()
    [bool]$IsValid = $true
    [string]$ValidationMessage
    [string]$SetupStatus
    [string]$OriginalSetupStatus
    [bool]$IsPlaceholder = $false

    # Complex editing support
    [bool]$IsComplex = $false
    [string]$ComplexKind
    [System.Collections.ArrayList]$ComplexItems = [System.Collections.ArrayList]::new()
    [hashtable]$ComplexMap = @{}
    [System.Collections.ArrayList]$ComplexSchema = [System.Collections.ArrayList]::new()

    SetupQuestion() {}
}

class SetupSection {
    [string]$Code
    [string]$Title
    [int]$Index
    [string]$Description
    [string]$Condition
    [System.Collections.Generic.List[SetupQuestion]]$Collection = [System.Collections.Generic.List[SetupQuestion]]::new()
    [System.Collections.Generic.List[SetupSection]]$WizardSectionCode    = [System.Collections.Generic.List[SetupSection]]::new()
}

# Global configuration value store (decouple question instances from underlying configuration code value)
if (-not $Global:ConfigurationStore) { $Global:ConfigurationStore = @{} }

function Register-SetupQuestionConfiguration {
    param([SetupQuestion]$Question)
    if (-not $Question) { return }
    $code = $Question.ConfigurationCode
    if ([string]::IsNullOrWhiteSpace($code)) { return }
    $store = $Global:ConfigurationStore
    $existing = $store[$code]
    if (-not $existing) {
        # Normalize initial value for arrays / complex
        $val = $Question.Value
        if ($Question.IsArray) { $val = @($Question.ArrayItems) }
        elseif ($Question.IsComplex) {
            if ($Question.ComplexKind -eq 'ObjectArray') { $val = @($Question.ComplexItems) }
            elseif ($Question.ComplexKind -eq 'ObjectMap') {
                $tmp = [ordered]@{}
                foreach ($k in $Question.ComplexMap.Keys){ $tmp[$k] = $Question.ComplexMap[$k] }
                $val = [pscustomobject]$tmp
            }
        }
        $existing = [pscustomobject]@{
            ConfigurationCode = $code
            Value             = $val
            OriginalValue     = $val
            IsArray           = $Question.IsArray
            IsComplex         = $Question.IsComplex
            ComplexKind       = $Question.ComplexKind
            Questions         = New-Object System.Collections.Generic.List[SetupQuestion]
        }
        $store[$code] = $existing
    } else {
        # Align question value with shared store (arrays/complex rehydrated separately later)
        if (-not $Question.IsArray -and -not $Question.IsComplex) {
            $Question.Value = $existing.Value
            $Question.OriginalValue = $existing.OriginalValue
        }
    }
    if (-not ($existing.Questions.Contains($Question))) { $existing.Questions.Add($Question) | Out-Null }
}

function New-SetupSection {
    param(
        [string]$Code,
        [string]$Title,
        [int]$Index,
        [string]$Description,
        [string]$Condition
    )
    $s = [SetupSection]::new()
    $s.Code        = $Code
    $s.Title       = $Title
    $s.Index       = $Index
    $s.Description = $Description
    $s.Condition   = $Condition
    return $s
}

function Parse-PrimitiveValue {
    param([object]$Value)
    if ($null -eq $Value) { return $null }
    if ($Value -is [bool]) { return $Value }
    if ($Value -is [int]) { return $Value }
    if ($Value -is [double]) { return $Value }
    if ($Value -is [string]) {
        $trim = $Value.Trim()
        if ($trim -match '^(?i:true|false)$') { return [bool]::Parse($trim.ToLower()) }
        if ($trim -match '^-?\d+$') { try { return [int]$trim } catch {} }
        if ($trim -match '^-?\d+\.\d+$') { try { return [double]$trim } catch {} }
        return $Value
    }
    return $Value
}

function Infer-ValueType {
    param([object]$Value,[string]$Declared)
    if ($Declared) { return $Declared }
    if ($null -eq $Value) { return '' }
    if ($Value -is [bool]) { return 'Bool' }
    if ($Value -is [int] -or $Value -is [long]) { return 'Int' }
    if ($Value -is [double] -or $Value -is [decimal]) { return 'Float' }
    if ($Value -is [System.Collections.IEnumerable] -and $Value -isnot [string]) { return 'Array' }
    return ''
}

function New-SetupQuestion {
    param(
        [string]$Code,
        [int]$Index,
        [string]$Question,
        [string]$Description,
        [string[]]$PossibleValues,
        [string]$ConfigurationCode,
        [string]$Condition,
        [object]$Value,
        [switch]$Hidden,
        [string]$ValueType,
        [string]$Regex,
        [string]$ValidationHookFunction,
        [switch]$AsObjectArray,
        [switch]$AsObjectMap,
        [object]$Schema
    )
    $q = [SetupQuestion]::new()
    $q.Code        = $Code
    $q.Index       = $Index
    $q.Question    = $Question
    $q.Description = $Description
    $q.PossibleValues = $PossibleValues
    $q.ConfigurationCode = $ConfigurationCode
    $q.Condition   = $Condition
    $q.ValidationHookFunction = $ValidationHookFunction

    $parsed = Parse-PrimitiveValue -Value $Value
    $q.Value = $parsed
    $q.OriginalValue = $parsed
    $q.Hidden      = $Hidden.IsPresent

    if ($AsObjectArray -and $AsObjectMap) { throw "A question cannot be both ObjectArray and ObjectMap." }

    if ($AsObjectArray) {
        $q.IsComplex   = $true
        $q.ComplexKind = 'ObjectArray'
        $q.ValueType   = 'ObjectArray'
        if ($Value -is [System.Collections.IEnumerable] -and $Value -isnot [string]) {
            foreach ($item in $Value) {
                if ($item -is [psobject] -or $item -is [hashtable]) { $q.ComplexItems.Add($item) | Out-Null }
            }
        }
    } elseif ($AsObjectMap) {
        $q.IsComplex   = $true
        $q.ComplexKind = 'ObjectMap'
        $q.ValueType   = 'ObjectMap'
        if ($Value -is [psobject]) {
            foreach ($p in $Value.PSObject.Properties) { $q.ComplexMap[$p.Name] = $p.Value }
        } elseif ($Value -is [hashtable]) {
            foreach ($k in $Value.Keys) { $q.ComplexMap[$k] = $Value[$k] }
        }
    } else {
        $inferred = Infer-ValueType -Value $parsed -Declared $ValueType
        $q.ValueType = $inferred
        if ($q.ValueType -eq 'Array' -and ($parsed -is [System.Collections.IEnumerable] -and $parsed -isnot [string])) {
            $q.IsArray = $true
            foreach ($v in $parsed) { [void]$q.ArrayItems.Add([string]$v) }
        } elseif ($q.ValueType -eq 'Array' -and [string]$parsed -like '*;*') {
            $q.IsArray = $true
            ($parsed -split ';') | Where-Object { $_ } | ForEach-Object { [void]$q.ArrayItems.Add($_) }
        }
    }

    if ($Schema) {
        if ($Schema -is [System.Collections.IEnumerable]) {
            foreach ($s in $Schema) { $q.ComplexSchema.Add($s) | Out-Null }
        } else {
            $q.ComplexSchema.Add($Schema) | Out-Null
        }
    }

    if (($q.Value -is [string]) -and $q.Value -like '*UNCONFIGUREDENTRY*') { $q.IsPlaceholder = $true }
    # Register in configuration store (decoupling): ensures shared value across questions with same ConfigurationCode
    Register-SetupQuestionConfiguration -Question $q
    return $q
}

$ConfigParameterVersion = '3.0'