<#
Logging.ps1
Adds:
 - Error logging (Write-ErrorLog)
 - Safe executor (Invoke-Safely)
 - Log cleaner function (called on demand if needed outside State)
#>

function Write-Log {
    param(
        [string]$Message,
        [string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString("o")
    $line = "[$ts] [$Level] $Message"
    Add-Content -LiteralPath $Global:AppState.LogFile -Value $line
}

function Write-TelemetryEvent {
    param(
        [string]$Action,
        [hashtable]$Data
    )
    $evt = [ordered]@{
        timestamp = (Get-Date).ToString('o')
        sessionId = $Global:AppState.SessionId
        action    = $Action
        data      = $Data
    }
    $json = ($evt | ConvertTo-Json -Depth 10 -Compress)
    Add-Content -LiteralPath $Global:AppState.TelemetryFile -Value $json
}

function Write-ErrorLog {
    param(
        [System.Management.Automation.ErrorRecord]$ErrorRecord,
        [string]$Context
    )
    $ts = (Get-Date).ToString('o')
    $ex  = $ErrorRecord.Exception
    $stack = $ex.StackTrace
    $line = @"
[$ts] [ERROR] Context: $Context
Message : $($ex.Message)
Category: $($ErrorRecord.CategoryInfo)
FullyQualifiedErrorId: $($ErrorRecord.FullyQualifiedErrorId)
ScriptStackTrace:
$($ErrorRecord.ScriptStackTrace)
Exception Type: $($ex.GetType().FullName)
StackTrace:
$stack
----------------------------------------------------------------
"@
    Add-Content -LiteralPath $Global:AppState.ErrorLogFile -Value $line
    Write-Log -Level 'ERROR' -Message "$Context :: $($ex.Message)"
}

function Log-And-Telemetry {
    param(
        [string]$Action,
        [string]$Message,
        [hashtable]$Data = @{}
    )
    try {
        Write-Log -Message "$Action - $Message"
        Write-TelemetryEvent -Action $Action -Data $Data
    } catch {
        Write-ErrorLog -ErrorRecord $_ -Context "Log-And-Telemetry($Action)"
    }
}

function Invoke-Safely {
    param(
        [scriptblock]$Code,
        [string]$Context = 'unknown'
    )
    try {
        & $Code
    } catch {
        Write-ErrorLog -ErrorRecord $_ -Context $Context
        [System.Windows.Forms.MessageBox]::Show("An error occurred: $Context`n`n$($_.Exception.Message)","Error","OK","Error") | Out-Null
    }
}

function Clean-OldLogs {
    param(
        [int]$RetentionDays = 7
    )
    if ($RetentionDays -le 0) { return }
    if (-not (Test-Path -LiteralPath $Global:AppState.LogDirectory)) { return }
    $threshold = (Get-Date).AddDays(-[math]::Abs($RetentionDays))
    Get-ChildItem -LiteralPath $Global:AppState.LogDirectory -File -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt $threshold } |
        ForEach-Object {
            try {
                Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop
                Write-Log -Message "Removed old log: $($_.Name)"
            } catch {
                Write-ErrorLog -ErrorRecord $_ -Context "Clean-OldLogs(remove:$($_.FullName))"
            }
        }
}