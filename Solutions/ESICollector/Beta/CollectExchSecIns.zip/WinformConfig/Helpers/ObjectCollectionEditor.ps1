<#
ObjectCollectionEditor.ps1
UPDATE (Expose all schema attributes for ObjectMap / ObjectArray items):
 - Ensures every schema-defined property is ALWAYS present (with empty string if no value) in:
     * Newly added ObjectArray element
     * Newly added ObjectMap entry
     * Duplicated entries (fills missing keys)
     * Grid display (keeps schema order first, then extra props)
     * Export (selected / all) – missing schema keys added with ""
 - Removed alphabetical sort that previously reordered properties; schema order is preserved,
   followed by any additional (non‑schema) properties in alphabetical order.
 - Commit logic already walks every row; unchanged except we now guarantee all schema props exist in the working object.
 - Added helper Initialize-EmptyItemFromSchema.
 - Added Normalize-ItemAgainstSchema to retrofit existing / imported items so UI & export are consistent.
 - When importing (selected or all) any missing schema keys added as empty string.

FIX (2025-09-02):
 - Prevent null key usage in schema lookup causing:
      Exception calling "ContainsKey" ... "Value cannot be null. (Parameter 'key')"
   Added defensive checks (if ($prop)) before every $schemaLookup.ContainsKey(...) call and in CellEnter/Load routines.
#>

param()

if (-not (Get-Command Log-And-Telemetry -ErrorAction SilentlyContinue)) {
    function Log-And-Telemetry { param([string]$Action,[string]$Message,[hashtable]$Data=@{}) Write-Host "LOG: $Action - $Message" }
}
if (-not (Get-Command Write-ErrorLog -ErrorAction SilentlyContinue)) {
    function Write-ErrorLog { param($ErrorRecord,[string]$Context) Write-Warning "$Context : $($ErrorRecord.Exception.Message)" }
}

function Convert-ItemToHashtable {
    param($Item)
    $h = @{}
    if ($Item -is [pscustomobject]) {
        foreach ($p in $Item.PSObject.Properties) { $h[$p.Name] = $p.Value }
    } elseif ($Item -is [hashtable]) {
        foreach ($k in $Item.Keys) { $h[$k] = $Item[$k] }
    }
    return $h
}
function Materialize-Hashtable { param($Hash) return [pscustomobject]$Hash }

function Invoke-WithErrorCapture {
    param([scriptblock]$Code,[string]$Context='complex_editor')
    try { & $Code } catch {
        Write-ErrorLog -ErrorRecord $_ -Context $Context
        Log-And-Telemetry -Action "complex_editor_error" -Message $Context -Data @{ error=$_.Exception.Message }
        [System.Windows.Forms.MessageBox]::Show("Error: $Context`n$($_.Exception.Message)","Error","OK","Error") | Out-Null
    }
}

function Get-SchemaLookup {
    param($Question)
    $lookup=@{}
    foreach ($s in $Question.ComplexSchema) {
        if ($s.Name) { $lookup[$s.Name]= $s }
    }
    return $lookup
}

function Convert-ArrayLikeValue {
    param($Value)
    if ($Value -is [System.Collections.IEnumerable] -and $Value -isnot [string]) {
        return ($Value | ForEach-Object { $_ }) -join ';'
    }
    return $Value
}

function Set-ValueWithTypeInference {
    param($SchemaEntry,[string]$Raw)
    if ($Raw -eq '' -or $null -eq $Raw) { return '' }
    if (-not $SchemaEntry) { return $Raw }
    switch ($SchemaEntry.Type) {
        'Bool' {
            if ($Raw -match '^(?i:true|false)$') { return [bool]::Parse($Raw.ToLower()) }
            return $false
        }
        'Int' {
            if ($Raw -match '^-?\d+$') {
                try { return [int]$Raw } catch { return 0 }
            }
            return 0
        }
        'Array' {
            return @($Raw -split ';' | Where-Object { $_ })
        }
        default { return $Raw }
    }
}

function Validate-ComplexEntry {
    param(
        [hashtable]$SchemaLookup,
        [hashtable]$Entry,
        [string]$Placeholder = 'UNCONFIGUREDENTRY'
    )
    # Local helper réutilisable pour condition
    function Test-SchemaConditionInternal {
        param($Meta,[hashtable]$Entry)
        $condOk = $true
        if ($Meta -and $Meta.Keys -contains 'Condition') {
            $cond = $Meta.Condition
            if ($cond) {
                try {
                    if ($cond -is [scriptblock]) {
                        $decl = $cond.ToString()
                        if ($decl -match '(?i)param') { $condOk = & $cond $Entry }
                        else {
                            Set-Variable -Name Entry -Value $Entry -Scope Local
                            try { $condOk = & $cond } finally { Remove-Variable Entry -ErrorAction SilentlyContinue }
                        }
                    } else {
                        $sb = [scriptblock]::Create($cond)
                        Set-Variable -Name Entry -Value $Entry -Scope Local
                        try { $condOk = & $sb } finally { Remove-Variable Entry -ErrorAction SilentlyContinue }
                    }
                    $condOk = [bool]$condOk
                } catch { $condOk = $false }
            }
        }
        return $condOk
    }
    $inactiveProps = @()
    foreach ($prop in $SchemaLookup.Keys) {
        $meta = $SchemaLookup[$prop]
        $condOk = Test-SchemaConditionInternal -Meta $meta -Entry $Entry
        if (-not $condOk) {
            # On ignore totalement cette propriété tant que la condition n'est pas satisfaite
            $inactiveProps += $prop
            continue
        }
        $isRequiredNow = ($meta.Required)
        if ($isRequiredNow) {
            $hasValue = $Entry.ContainsKey($prop)
            $val = $null
            if ($hasValue) { $val = $Entry[$prop] }
            $isEmpty = (-not $hasValue) -or ([string]::IsNullOrWhiteSpace("$val"))
            $isPlaceholder = ($val -is [string] -and $val -like "*${Placeholder}*")
            if ($isEmpty -or $isPlaceholder) {
                $reason = if ($isPlaceholder) { "placeholder value" } else { "missing" }
                return @{ IsValid=$false; Message="Required property '$prop' $reason." }
            }
        }
        if ($Entry.ContainsKey($prop) -and $meta.Type -eq 'Bool') {
            $v=$Entry[$prop]
            if (($null -ne $v -and $v -isnot [bool]) -or ($v -is [string] -and -not [String]::IsNullOrEmpty($v))) {
                if ($v -is [string] -and $v -match '^(?i:true|false)$') {
                    $Entry[$prop]=[bool]::Parse($v.ToLower())
                } else {
                    if ($v -is [string] -and [String]::IsNullOrEmpty($v)) {
                        $Entry[$prop]=$null
                    }
                    else {
                        return @{ IsValid=$false; Message="Property '$prop' must be boolean." }
                    }
                }
            }
        }
        if ($Entry.ContainsKey($prop) -and $meta.Type -eq 'Int') {
            $v=$Entry[$prop]
            if (($null -ne $v -and $v -isnot [int]) -or ($v -is [string] -and -not [String]::IsNullOrEmpty($v))) {
                if ($v -is [string] -and $v -match '^-?\d+$') {
                    try { $Entry[$prop]=[int]$v } catch { return @{ IsValid=$false; Message="Property '$prop' must be integer." } }
                } else {
                    if ($v -is [string] -and [String]::IsNullOrEmpty($v)) {
                        $Entry[$prop]=$null
                    }
                    else {
                        return @{ IsValid=$false; Message="Property '$prop' must be integer." }
                    }
                }
            }
        }
        # PossibleValues validation (uniquement si valeur présente et condition active)
        if ($Entry.ContainsKey($prop) -and $meta.PSObject.Properties.Name -contains 'PossibleValues' -and $meta.PossibleValues -and $Entry[$prop] -ne '') {
            $allowed = @($meta.PossibleValues | ForEach-Object { "$_" })
            $valCurrent = $Entry[$prop]
            if ($meta.Type -eq 'Array' -and $valCurrent -isnot [System.Collections.IEnumerable]) {
                # Valeur non normalisée (devrait être tableau) – on tente split si string
                if ($valCurrent -is [string]) { $valCurrent = @($valCurrent -split ';' | Where-Object { $_ }) }
            }
            if ($meta.Type -eq 'Array' -and $valCurrent -is [System.Collections.IEnumerable] -and $valCurrent -isnot [string]) {
                foreach ($elem in $valCurrent) {
                    if ($elem -and ($allowed -notcontains "$elem")) {
                        return @{ IsValid=$false; Message="Property '$prop' element '$elem' not in allowed list." }
                    }
                }
            } else {
                $scalar = "$valCurrent"
                if ($scalar -and ($allowed -notcontains $scalar)) {
                    return @{ IsValid=$false; Message="Property '$prop' value '$scalar' not in allowed list." }
                }
            }
        }
    }
    # Placeholder detection
    foreach ($k in $Entry.Keys) {
        $raw = $Entry[$k]
        if ($raw -is [string] -and $raw -like "*$Placeholder*") {
            return @{ IsValid=$false; Message="Property '$k' still contains placeholder '$Placeholder'." }
        }
        if ($raw -is [System.Collections.IEnumerable] -and $raw -isnot [string]) {
            foreach ($x in $raw) {
                if ($x -is [string] -and $x -like "*$Placeholder*") {
                    return @{ IsValid=$false; Message="Property '$k' contains placeholder '$Placeholder' in array element." }
                }
            }
        }
    }
    return @{ IsValid=$true; Message=""; Inactive=$inactiveProps }
}

# ---- NEW HELPERS FOR FULL SCHEMA EXPOSURE ----
function Initialize-EmptyItemFromSchema {
    param([hashtable]$SchemaLookup)
    $h = @{}
    foreach ($k in $SchemaLookup.Keys) {
        $h[$k] = ''   # empty string as placeholder (not UNCONFIGUREDENTRY)
    }
    return $h
}
function Normalize-ItemAgainstSchema {
    param([hashtable]$Item,[hashtable]$SchemaLookup)
    foreach ($k in $SchemaLookup.Keys) {
        if (-not $Item.ContainsKey($k)) { $Item[$k] = '' }
    }
    return $Item
}

function Show-ObjectCollectionEditor {
    param(
        [Parameter(Mandatory)][SetupQuestion]$Question,
        [string]$Title = 'Object Collection Editor'
    )

    Log-And-Telemetry -Action "complex_editor_open" -Message "Opening complex editor" -Data @{ code=$Question.Code; kind=$Question.ComplexKind }

    if (-not $Question.IsComplex) {
        Log-And-Telemetry -Action "complex_editor_abort" -Message "Question is not complex" -Data @{ code=$Question.Code }
        return $null
    }

    $schemaLookup = Get-SchemaLookup -Question $Question
    $tooltip = New-Object System.Windows.Forms.ToolTip

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$Title - $($Question.Question)"
    $dlg.Width = 1120
    $dlg.Height = 720
    $dlg.StartPosition = 'CenterParent'

    $split = New-Object System.Windows.Forms.SplitContainer
    $split.Dock='Fill'
    $split.SplitterDistance=50
    $dlg.Controls.Add($split)

    # LEFT :: list + buttons
    $panelLeftTop = New-Object System.Windows.Forms.Panel
    $panelLeftTop.Dock='Fill'
    $split.Panel1.Controls.Add($panelLeftTop)

    $list = New-Object System.Windows.Forms.ListBox
    $list.Anchor='Top,Bottom,Left,Right'
    $list.Location='6,6'
    $list.Width = $panelLeftTop.Width - 12
    $list.Height = $panelLeftTop.Height - 150
    $panelLeftTop.Controls.Add($list)

    $panelLeftButtons = New-Object System.Windows.Forms.Panel
    $panelLeftButtons.Dock='Bottom'
    $panelLeftButtons.Height=140
    $panelLeftTop.Controls.Add($panelLeftButtons)

    $btnAdd      = New-Object System.Windows.Forms.Button -Property @{ Text='Add'; Width=120; Location='6,6' }
    $btnDup      = New-Object System.Windows.Forms.Button -Property @{ Text='Duplicate'; Width=120; Location='6,42' }
    $btnRemove   = New-Object System.Windows.Forms.Button -Property @{ Text='Remove'; Width=120; Location='6,78' }
    $btnRename   = New-Object System.Windows.Forms.Button -Property @{ Text='Rename'; Width=120; Location='150,6'; Visible=($Question.ComplexKind -eq 'ObjectMap') }
    $btnExportSel= New-Object System.Windows.Forms.Button -Property @{ Text='Export'; Width=120; Location='150,42' }
    $btnImport   = New-Object System.Windows.Forms.Button -Property @{ Text='Import'; Width=120; Location='150,78' }

    $panelLeftButtons.Controls.AddRange(@($btnAdd,$btnDup,$btnRemove,$btnRename,$btnExportSel,$btnImport))

    # RIGHT :: grid + description + bottom buttons
    $panelRight = New-Object System.Windows.Forms.Panel
    $panelRight.Dock='Fill'
    $split.Panel2.Controls.Add($panelRight)

    $grid = New-Object System.Windows.Forms.DataGridView
    $grid.Location='6,6'
    $grid.Anchor='Top,Left,Right'
    $grid.Height=380
    $grid.Width = $panelRight.Width - 12
    $grid.AllowUserToAddRows=$false
    $grid.AllowUserToDeleteRows=$false
    $grid.RowHeadersVisible=$false
    $grid.SelectionMode='CellSelect'
    $grid.EditMode='EditOnEnter'
    $grid.AutoSizeColumnsMode='Fill'
    $panelRight.Controls.Add($grid)

    $colProp = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colProp.Name='Property'; $colProp.ReadOnly=$true
    $colVal  = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colVal.Name='Value'
    [void]$grid.Columns.Add($colProp)
    [void]$grid.Columns.Add($colVal)

    $lblDescHeader = New-Object System.Windows.Forms.Label
    $lblDescHeader.Text='Property Description'
    $lblDescHeader.Font = New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
    $lblDescHeader.AutoSize=$true
    $lblDescHeader.Location='6,398'
    $panelRight.Controls.Add($lblDescHeader)

    $txtDesc = New-Object System.Windows.Forms.RichTextBox
    $txtDesc.Location='6,424'
    $txtDesc.Width = $panelRight.Width - 12
    $txtDesc.Height=110   # reduced to leave room for invalid reason panel
    $txtDesc.Anchor='Top,Left,Right'
    $txtDesc.ReadOnly=$true
    $panelRight.Controls.Add($txtDesc)

    # --- Invalid reason panel (hidden unless item invalid) ---
    $lblInvalid = New-Object System.Windows.Forms.Label
    $lblInvalid.Text = 'Item Validation Issues'
    $lblInvalid.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
    $lblInvalid.AutoSize = $true
    $lblInvalid.Location = '6,540'
    $lblInvalid.Visible = $false
    $panelRight.Controls.Add($lblInvalid)

    $txtInvalid = New-Object System.Windows.Forms.TextBox
    $txtInvalid.Multiline=$true; $txtInvalid.ReadOnly=$true
    $txtInvalid.ScrollBars='Vertical'
    $txtInvalid.Width = $panelRight.Width - 12
    $txtInvalid.Height = 60
    $txtInvalid.Location='6,560'
    $txtInvalid.Anchor='Top,Left,Right'
    $txtInvalid.Visible = $false
    $panelRight.Controls.Add($txtInvalid)

    $panelBottom = New-Object System.Windows.Forms.Panel
    $panelBottom.Dock='Bottom'
    $panelBottom.Height=60
    $panelRight.Controls.Add($panelBottom)

    $btnExportAll = New-Object System.Windows.Forms.Button -Property @{ Text='Export All'; Width=140; Location='6,14' }
    $btnImportAll = New-Object System.Windows.Forms.Button -Property @{ Text='Import All'; Width=140; Location='152,14' }
    $btnOK        = New-Object System.Windows.Forms.Button -Property @{ Text='OK'; Width=140; Location='480,14' }
    $btnCancel    = New-Object System.Windows.Forms.Button -Property @{ Text='Cancel'; Width=140; Location='626,14' }
    $panelBottom.Controls.AddRange(@($btnExportAll,$btnImportAll,$btnOK,$btnCancel))

    $tooltip.SetToolTip($btnAdd,'Add new object (all schema properties blank).')
    $tooltip.SetToolTip($btnDup,'Duplicate selected object (adds missing schema props).')
    $tooltip.SetToolTip($btnRemove,'Remove selected object.')
    $tooltip.SetToolTip($btnRename,'Rename selected key (ObjectMap only).')
    $tooltip.SetToolTip($btnExportSel,'Export selected item as JSON.')
    $tooltip.SetToolTip($btnImport,'Import/replace selected item from JSON.')
    $tooltip.SetToolTip($btnExportAll,'Export entire collection as JSON snippet.')
    $tooltip.SetToolTip($btnImportAll,'Import entire collection from JSON snippet (replaces current).')

    # ---- Read-Only enforcement (propagated) ----
    $isRO = ($Global:AppState -and $Global:AppState.ReadOnly)
    if ($isRO) {
        if ($dlg.Text -notmatch 'Read-Only') { $dlg.Text += ' (Read-Only)' }
        foreach ($b in @($btnAdd,$btnDup,$btnRemove,$btnRename,$btnImport,$btnImportAll)) { if ($b) { $b.Enabled = $false } }
        $grid.ReadOnly = $true
        $grid.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(235,235,235)
        $btnOK.Text = 'Close'
        $btnCancel.Visible = $false
    }

    # Working copies
    if ($Question.ComplexKind -eq 'ObjectArray') {
        $workingItems = New-Object System.Collections.ArrayList
        foreach ($it in $Question.ComplexItems) {
            $hash = Convert-ItemToHashtable $it
            Normalize-ItemAgainstSchema -Item $hash -SchemaLookup $schemaLookup | Out-Null
            [void]$workingItems.Add((Materialize-Hashtable -Hash $hash))
        }
    } else {
        $workingMap = [ordered]@{}
        foreach ($k in $Question.ComplexMap.Keys) {
            $hash = Convert-ItemToHashtable $Question.ComplexMap[$k]
            Normalize-ItemAgainstSchema -Item $hash -SchemaLookup $schemaLookup | Out-Null
            $workingMap[$k] = (Materialize-Hashtable -Hash $hash)
        }
    }

    # Gardes et drapeau de planification (évite réentrance SetCurrentCellAddressCore)
    $script:commitReentryGuard = $false
    $script:commitDeferred = $false
    # Version d’invalidation des commits différés
    $script:commitVersion = 0

    function Schedule-CommitGridEdits {
        if ($isRO) { return }
        if ($list.Tag -and $list.Tag.ContainsKey('Closing') -and $list.Tag.Closing) { return }
        if ($script:commitDeferred) { return }
        $script:commitDeferred = $true
        $script:localVersion = ++$script:commitVersion
        # Diffère à la boucle UI pour laisser DataGridView terminer sa mise à jour interne
        [void]$grid.BeginInvoke([Action]{
            try {
                if ($script:localVersion -ne $script:commitVersion) { return }
                Commit-GridEdits
            } finally { $script:commitDeferred = $false }
        })
    }

    # Réévalue les conditions des propriétés et ajuste le style / lecture seule dynamiquement
    function Refresh-ConditionalStyling {
        if ($list.SelectedIndex -lt 0) { return }
        # Reconstruire l'objet courant (après commit il est à jour dans workingItems / workingMap)
        $currentHash=@{}
        if ($Question.ComplexKind -eq 'ObjectArray') {
            if ($list.SelectedIndex -ge 0 -and $list.SelectedIndex -lt $workingItems.Count) {
                $currentHash = Convert-ItemToHashtable $workingItems[$list.SelectedIndex]
            }
        } else {
            $key = ($list.SelectedItem -replace '\s\*INVALID\*$','')
            if ($key -and $workingMap.Contains($key)) { $currentHash = Convert-ItemToHashtable $workingMap[$key] }
        }
        if (-not $currentHash) { return }
        # Helper local d'évaluation (copie logique Validate-ComplexEntry/Test-SchemaConditionInternal)
        function _EvalCond([object]$meta,[hashtable]$entry) {
            $ok=$true
            if ($meta -and $meta.PSObject.Properties.Name -contains 'Condition') {
                $cond=$meta.Condition
                if ($cond) {
                    try {
                        if ($cond -is [scriptblock]) {
                            $decl=$cond.ToString()
                            if ($decl -match '(?i)param') { $ok=& $cond $entry } else { Set-Variable Entry $entry -Scope Local; try { $ok=& $cond } finally { Remove-Variable Entry -ErrorAction SilentlyContinue } }
                        } else {
                            $sb=[scriptblock]::Create($cond); Set-Variable Entry $entry -Scope Local; try { $ok=& $sb } finally { Remove-Variable Entry -ErrorAction SilentlyContinue }
                        }
                        $ok=[bool]$ok
                    } catch { $ok=$false }
                }
            }
            return $ok
        }
        function _ApplyMandatory([System.Windows.Forms.DataGridViewRow]$row,[hashtable]$entry) {
            $prop = $row.Cells[0].Value
            if (-not $prop) { return }
            if (-not $schemaLookup.ContainsKey($prop)) { return }
            if ($row.Cells[0].Tag -eq 'INACTIVE') { return } # ne force pas le rouge sur lignes inactives
            $meta = $schemaLookup[$prop]
            $isReq = $meta.Required
            if (-not $isReq) {
                # reset éventuel
                $row.Cells[1].Style.BackColor = [System.Drawing.Color]::White
                $row.Cells[1].Style.ForeColor = [System.Drawing.Color]::Black
                return
            }
            $val = $null
            if ($entry.ContainsKey($prop)) { $val = $entry[$prop] }
            $str = if ($null -ne $val) { "$val" } else { '' }
            $isPlaceholder = ($str -match 'UNCONFIGUREDENTRY')
            if ([string]::IsNullOrWhiteSpace($str) -or $isPlaceholder) {
                $row.Cells[1].Style.BackColor = [System.Drawing.Color]::FromArgb(255,220,220)
                $row.Cells[1].Style.ForeColor = [System.Drawing.Color]::DarkRed
            } else {
                $row.Cells[1].Style.BackColor = [System.Drawing.Color]::White
                $row.Cells[1].Style.ForeColor = [System.Drawing.Color]::Black
            }
        }
        foreach ($row in $grid.Rows) {
            $prop = $row.Cells[0].Value
            if (-not $prop) { continue }
            if ($schemaLookup.ContainsKey($prop)) {
                $meta = $schemaLookup[$prop]
                $active = _EvalCond -meta $meta -entry $currentHash
                $currentlyInactive = ($row.Cells[0].Tag -eq 'INACTIVE')
                if ($active -and $currentlyInactive) {
                    # Ré-active
                    $row.Cells[0].Tag = $null
                    if (-not $isRO) { $row.Cells[1].ReadOnly = $false }
                    $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::Black
                    $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::White
                } elseif (-not $active -and -not $currentlyInactive) {
                    # Désactive
                    $row.Cells[0].Tag = 'INACTIVE'
                    $row.Cells[1].ReadOnly = $true
                    $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::DarkGray
                    $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(245,245,245)
                    # Nettoie éventuel style rouge
                    $row.Cells[1].Style.BackColor = $row.DefaultCellStyle.BackColor
                    $row.Cells[1].Style.ForeColor = $row.DefaultCellStyle.ForeColor
                }
                if ($active) { _ApplyMandatory -row $row -entry $currentHash }
            }
        }
    }

    function Refresh-List {
        $list.Items.Clear()
        if ($Question.ComplexKind -eq 'ObjectArray') {
            for ($i=0;$i -lt $workingItems.Count;$i++) {
                $it=$workingItems[$i]
                $hash=Convert-ItemToHashtable $it
                $label="#$i"
                if ($hash.ContainsKey('Name') -and $hash.Name) { $label = "$label - $($hash.Name)" }
                elseif ($hash.ContainsKey('StorageType') -and $hash.StorageType) { $label = "$label - $($hash.StorageType)" }
                elseif ($hash.ContainsKey('Filename') -and $hash.Filename) { $label = "$label - $($hash.Filename)" }
                [void]$list.Items.Add($label)
            }
        } else {
            foreach ($k in ($workingMap.Keys | Sort-Object)) { [void]$list.Items.Add($k) }
        }
    }

    function Load-SelectedObjectToGrid {
        $grid.Rows.Clear()
        $txtDesc.Clear()
        # Clear invalid panel by default
        $lblInvalid.Visible = $false; $txtInvalid.Visible=$false; $txtInvalid.Text=''
        if ($list.SelectedIndex -lt 0) { return }
        $itemHash=@{}
        if ($Question.ComplexKind -eq 'ObjectArray') {
            $idx=$list.SelectedIndex
            $itemHash=Convert-ItemToHashtable $workingItems[$idx]
        } else {
            $key=$list.SelectedItem
            $itemHash=Convert-ItemToHashtable $workingMap[$key]
        }
        Normalize-ItemAgainstSchema -Item $itemHash -SchemaLookup $schemaLookup | Out-Null

        # Validation for selected item (detailed first failing error only)
        $resSelected = Validate-ComplexEntry -SchemaLookup $schemaLookup -Entry $itemHash
        if (-not $resSelected.IsValid) {
            $lblInvalid.Visible = $true
            $txtInvalid.Visible = $true
            $txtInvalid.Text = $resSelected.Message
        }

        # Order: schema order then extras
        $schemaOrder = @()
        foreach ($sk in $schemaLookup.Keys) { $schemaOrder += $sk }
        $extras = @()
        foreach ($k in $itemHash.Keys) { if ($schemaOrder -notcontains $k) { $extras += $k } }
        $extras = $extras | Sort-Object
        $finalOrder = $schemaOrder + $extras

        foreach ($p in $finalOrder) {
            if (-not $p) { continue }
            $v = if ($itemHash.ContainsKey($p)) { Convert-ArrayLikeValue $itemHash[$p] } else { '' }
            $rIdx=$grid.Rows.Add()
            $grid.Rows[$rIdx].Cells[0].Value=$p
            $grid.Rows[$rIdx].Cells[1].Value="$v"
            if ($p -and $schemaLookup.ContainsKey($p)) {
                $meta = $schemaLookup[$p]
                $desc=$meta.Description
                $condActive = $true
                if ($meta.keys -contains 'Condition') {
                    try {
                        $condActive = (Validate-ComplexEntry).GetType() # placeholder to ensure function loaded
                    } catch {}
                    # ré-évalue simplement la condition via même logique que validation
                    $condActive = $true
                    try {
                        if ($meta.Condition) {
                            if ($meta.Condition -is [scriptblock]) {
                                $decl=$meta.Condition.ToString(); if ($decl -match '(?i)param') { $condActive=& $meta.Condition $itemHash } else { Set-Variable Entry $itemHash -Scope Local; try { $condActive=& $meta.Condition } finally { Remove-Variable Entry -ErrorAction SilentlyContinue } }
                            } else {
                                $sb=[scriptblock]::Create($meta.Condition); Set-Variable Entry $itemHash -Scope Local; try { $condActive=& $sb } finally { Remove-Variable Entry -ErrorAction SilentlyContinue }
                            }
                            $condActive=[bool]$condActive
                        }
                    } catch { $condActive=$false }
                }
                if (-not $condActive) {
                    # Style grisé + lecture seule (non éditable)
                    $row = $grid.Rows[$rIdx]
                    $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::DarkGray
                    $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(245,245,245)
                    $row.Cells[1].ReadOnly = $true
                    # Indicateur flag pour Commit-GridEdits (stocké en Tag cellule 0)
                    $row.Cells[0].Tag = 'INACTIVE'
                    if ($desc) { $desc += " (inactive condition)" } else { $desc = '(inactive condition)' }
                }
                else
                {
                    # Applique styling mandatory si requis et vide / placeholder
                    $row = $grid.Rows[$rIdx]
                    if ($meta.Required) {
                        $rawStr = "$v"
                        if ([string]::IsNullOrWhiteSpace($rawStr) -or $rawStr -match 'UNCONFIGUREDENTRY') {
                            $row.Cells[1].Style.BackColor = [System.Drawing.Color]::FromArgb(255,220,220)
                            $row.Cells[1].Style.ForeColor = [System.Drawing.Color]::DarkRed
                        }
                    }
                }
                if ($desc) { $tooltip.SetToolTip($grid,"$p : $desc") }
            }
        }
        Update-ValidationStatus
        # Refresh invalid panel after status update (in case list flags changed name)
        if ($resSelected -and $resSelected.IsValid) {
            $lblInvalid.Visible = $false; $txtInvalid.Visible=$false; $txtInvalid.Text=''
        }
    }

    function Commit-GridEdits {
        param([int]$IndexOverride = -1,[string]$KeyOverride)
        if ($isRO) { return }
        # Ne pas committer si on est en phase de fermeture
        $tagState = $list.Tag
        if ($tagState -and $tagState.ContainsKey('Closing') -and $tagState.Closing) { return }
    if ($script:commitReentryGuard) { return }
    $script:commitReentryGuard = $true
        try {
        $targetIndex = if ($IndexOverride -ge 0) { $IndexOverride } else { $list.SelectedIndex }
        if ($targetIndex -lt 0) { return }
        # Protection: si la grille est vide (premier chargement avant remplissage), ne pas écraser l'objet existant
        $hasData = $false
        foreach ($row in $grid.Rows) {
            if ($row.Cells.Count -gt 0 -and $row.Cells[0].Value) { $hasData = $true; break }
        }
        if (-not $hasData) { return }
        $itemHash=@{}
        foreach ($row in $grid.Rows) {
            $p=$row.Cells[0].Value
            if (-not $p) { continue }
            # Ignore propriétés inactives (condition false)
            if ($row.Cells[0].Tag -eq 'INACTIVE') { continue }
            $val=$row.Cells[1].Value
            $schemaEntry = if ($p -and $schemaLookup.ContainsKey($p)) { $schemaLookup[$p] } else { $null }
            $itemHash[$p] = Set-ValueWithTypeInference -SchemaEntry $schemaEntry -Raw $val
        }
        Normalize-ItemAgainstSchema -Item $itemHash -SchemaLookup $schemaLookup | Out-Null
        if ($Question.ComplexKind -eq 'ObjectArray') {
            if ($targetIndex -ge 0 -and $targetIndex -lt $workingItems.Count) {
                $workingItems[$targetIndex] = Materialize-Hashtable -Hash $itemHash
            } else { return }
        } else {
            $key = if ($KeyOverride) { $KeyOverride } else { $list.SelectedItem }
            if ($key) { $key = ($key -replace '\s\*INVALID\*$','') }
            if ($key -and $workingMap.Contains($key)) {
                $workingMap[$key] = Materialize-Hashtable -Hash $itemHash
            } else { return }
        }
    # Rafraîchir style conditionnel immédiatement après commit
    Refresh-ConditionalStyling
        Update-ValidationStatus
    } finally { $script:commitReentryGuard = $false }
    }

    function Update-ValidationStatus {
        if ($Question.ComplexKind -eq 'ObjectArray') {
            for ($i=0;$i -lt $workingItems.Count;$i++) {
                $hash=Convert-ItemToHashtable $workingItems[$i]
                
                Normalize-ItemAgainstSchema -Item $hash -SchemaLookup $schemaLookup | Out-Null
                $res=Validate-ComplexEntry -SchemaLookup $schemaLookup -Entry $hash
                if (-not $res.IsValid) {
                    if ($list.Items[$i] -notmatch '\*INVALID\*$') {
                        $list.Items[$i] = "$($list.Items[$i]) *INVALID*"
                    }
                } else {
                    $list.Items[$i] = ($list.Items[$i] -replace '\s\*INVALID\*$','')
                }
            }
        } else {
            for ($i=0;$i -lt $list.Items.Count;$i++) {
                $k=$list.Items[$i] -replace '\s\*INVALID\*$',''
                $hash=Convert-ItemToHashtable $workingMap[$k]
                Normalize-ItemAgainstSchema -Item $hash -SchemaLookup $schemaLookup | Out-Null
                $res=Validate-ComplexEntry -SchemaLookup $schemaLookup -Entry $hash
                if (-not $res.IsValid) {
                    if ($list.Items[$i] -notmatch '\*INVALID\*$') {
                        $list.Items[$i] = "$k *INVALID*"
                    }
                } else {
                    $list.Items[$i] = $k
                }
            }
        }
    }

    $script:InternalUpdate = $false

    # Track last selected index to commit correct item before switching
    $list.Tag = @{ LastIndex = -1; Closing = $false }
    $list.Add_SelectedIndexChanged({
        $tag = $list.Tag
        if ($script:InternalUpdate) {return}
        $script:InternalUpdate = $true
        if ($tag -and $tag.ContainsKey('Closing') -and $tag.Closing) { return }
    # Invalide tout commit différé en attente avant de changer de sélection
    $script:commitVersion++
        # Commit previous selection (not the newly selected index)
        $prev = -1
        if ($tag -and $tag.ContainsKey('LastIndex')) { $prev = $tag.LastIndex }
        if ($prev -ge 0 -and $prev -lt $list.Items.Count) {
            if ($Question.ComplexKind -eq 'ObjectMap') {
                $prevKey = ($list.Items[$prev] -replace '\s\*INVALID\*$','')
                Commit-GridEdits -IndexOverride $prev -KeyOverride $prevKey
            } else {
                Commit-GridEdits -IndexOverride $prev
            }
        }
        # Load new selection
        Load-SelectedObjectToGrid
        # Update last index
        $script:InternalUpdate = $false
        $list.Tag.LastIndex = $list.SelectedIndex
    })

    # Buttons
    $btnAdd.Add_Click({
    if ($isRO) { return }
        Invoke-WithErrorCapture -Context 'complex_add' -Code {
            $blank = Initialize-EmptyItemFromSchema -SchemaLookup $schemaLookup
            if ($Question.ComplexKind -eq 'ObjectArray') {
                $workingItems.Add( (Materialize-Hashtable -Hash $blank) ) | Out-Null
            } else {
                $base="Instance"
                $i=1
                while ($workingMap.Contains("$base$i")) { $i++ }
                $workingMap["$base$i"]= (Materialize-Hashtable -Hash $blank)
            }
            Refresh-List
            $list.SelectedIndex = $list.Items.Count-1
            Log-And-Telemetry -Action "complex_add" -Message "Entry added" -Data @{ code=$Question.Code }
        }
    })
    $btnDup.Add_Click({
    if ($isRO) { return }
        Invoke-WithErrorCapture -Context 'complex_duplicate' -Code {
            if ($list.SelectedIndex -lt 0) { return }
            Commit-GridEdits
            if ($Question.ComplexKind -eq 'ObjectArray') {
                $idx=$list.SelectedIndex
                $orig=Convert-ItemToHashtable $workingItems[$idx]
                Normalize-ItemAgainstSchema -Item $orig -SchemaLookup $schemaLookup | Out-Null
                $workingItems.Add( (Materialize-Hashtable -Hash $orig) ) | Out-Null
                Refresh-List
                $list.SelectedIndex=$workingItems.Count-1
            } else {
                $key=$list.SelectedItem -replace '\s\*INVALID\*$',''
                $orig=Convert-ItemToHashtable $workingMap[$key]
                Normalize-ItemAgainstSchema -Item $orig -SchemaLookup $schemaLookup | Out-Null
                $newKey="${key}_Copy"
                $n=1
                while ($workingMap.Contains($newKey)) { $n++; $newKey="${key}_Copy$n" }
                $workingMap[$newKey] = Materialize-Hashtable -Hash $orig
                Refresh-List
                $list.SelectedItem=$newKey
            }
            Log-And-Telemetry -Action "complex_duplicate" -Message "Entry duplicated" -Data @{ code=$Question.Code }
        }
    })
    $btnRemove.Add_Click({
    if ($isRO) { return }
        Invoke-WithErrorCapture -Context 'complex_remove' -Code {
            if ($list.SelectedIndex -lt 0) { return }
            $idx=$list.SelectedIndex
            if ($Question.ComplexKind -eq 'ObjectArray') {
                $workingItems.RemoveAt($idx)
            } else {
                $key=$list.Items[$idx] -replace '\s\*INVALID\*$',''
                $workingMap.Remove($key)
            }
            Refresh-List
            if ($list.Items.Count -gt 0) { $list.SelectedIndex = [Math]::Min($idx, $list.Items.Count-1) }
            Load-SelectedObjectToGrid
            Log-And-Telemetry -Action "complex_remove" -Message "Entry removed" -Data @{ code=$Question.Code }
        }
    })
    $btnRename.Add_Click({
    if ($isRO) { return }
        Invoke-WithErrorCapture -Context 'complex_rename' -Code {
            if ($Question.ComplexKind -ne 'ObjectMap' -or $list.SelectedIndex -lt 0) { return }
            $old=$list.SelectedItem -replace '\s\*INVALID\*$',''
            $new=[Microsoft.VisualBasic.Interaction]::InputBox("New name:","Rename",$old)
            if ($new -and $new -ne $old -and -not $workingMap.Contains($new)) {
                $val=$workingMap[$old]
                $workingMap.Remove($old)
                $workingMap[$new]=$val
                Refresh-List
                $list.SelectedItem=$new
                Log-And-Telemetry -Action "complex_rename" -Message "Renamed" -Data @{ old=$old; new=$new }
            }
        }
    })

    function Get-WorkingCollectionAsObject {
        if ($Question.ComplexKind -eq 'ObjectArray') {
            $arr=@()
            foreach ($it in $workingItems) {
                $h = Convert-ItemToHashtable $it
                Normalize-ItemAgainstSchema -Item $h -SchemaLookup $schemaLookup | Out-Null
                $arr += (Materialize-Hashtable -Hash $h)
            }
            return $arr
        } else {
            $ht=[ordered]@{}
            foreach ($k in $workingMap.Keys) {
                $h = Convert-ItemToHashtable $workingMap[$k]
                Normalize-ItemAgainstSchema -Item $h -SchemaLookup $schemaLookup | Out-Null
                $ht[$k]=(Materialize-Hashtable -Hash $h)
            }
            return [pscustomobject]$ht
        }
    }

    function Convert-AllNumbersAndBoolsToStrings {
        param([ref]$Obj)
        if ($null -eq $Obj.Value) { return }
        if ($Obj.Value -is [bool]) {
            $Obj.Value = if ($Obj.Value) { 'true' } else { 'false' }; return
        }
        if ($Obj.Value -is [int] -or $Obj.Value -is [long] -or $Obj.Value -is [double] -or $Obj.Value -is [decimal]) {
            $Obj.Value = "$($Obj.Value)"; return
        }
        if ($Obj.Value -is [string]) { return }
        if ($Obj.Value -is [System.Collections.IEnumerable] -and $Obj.Value -isnot [string]) {
            if ($Obj.Value -is [hashtable]) {
                foreach ($k in @($Obj.Value.Keys)) {
                    $tmp = $Obj.Value[$k]
                    Convert-AllNumbersAndBoolsToStrings ([ref]$tmp)
                    $Obj.Value[$k]=$tmp
                }
            } elseif ($Obj.Value -is [pscustomobject]) {
                foreach ($p in $Obj.Value.PSObject.Properties) {
                    $tmp = $p.Value
                    Convert-AllNumbersAndBoolsToStrings ([ref]$tmp)
                    $Obj.Value | Add-Member -NotePropertyName $p.Name -NotePropertyValue $tmp -Force
                }
            } else {
                $new = @()
                foreach ($el in $Obj.Value) {
                    $tmp=$el
                    Convert-AllNumbersAndBoolsToStrings ([ref]$tmp)
                    $new += $tmp
                }
                $Obj.Value = $new
            }
        }
    }

    function Export-Collection([switch]$Selected) {
        Commit-GridEdits
        $exportObj = $null
        if ($Selected) {
            if ($list.SelectedIndex -lt 0) {
                [System.Windows.Forms.MessageBox]::Show("Nothing selected.","Export","OK","Information") | Out-Null
                return
            }
            if ($Question.ComplexKind -eq 'ObjectArray') {
                $h = Convert-ItemToHashtable $workingItems[$list.SelectedIndex]
                Normalize-ItemAgainstSchema -Item $h -SchemaLookup $schemaLookup | Out-Null
                $exportObj = @((Materialize-Hashtable -Hash $h))
            } else {
                $k=$list.SelectedItem -replace '\s\*INVALID\*$',''
                $h = Convert-ItemToHashtable $workingMap[$k]
                Normalize-ItemAgainstSchema -Item $h -SchemaLookup $schemaLookup | Out-Null
                $exportObj = ([ordered]@{ $k = (Materialize-Hashtable -Hash $h) })
            }
        } else {
            $exportObj = Get-WorkingCollectionAsObject
        }

        $ref = $exportObj
        Convert-AllNumbersAndBoolsToStrings ([ref]$ref)

        $json = ($ref | ConvertTo-Json -Depth 80)
        [Windows.Forms.Clipboard]::SetText($json)
        [Windows.Forms.MessageBox]::Show("JSON snippet exported to clipboard.","Export","OK","Information") | Out-Null
        Log-And-Telemetry -Action "complex_export" -Message "Export successful" -Data @{ code=$Question.Code; selected=$Selected.IsPresent; length=$json.Length }
    }

    function Import-Collection([switch]$Selected,[switch]$ReplaceAll) {
        $text = [Windows.Forms.Clipboard]::GetText()
        if (-not $text) {
            [Windows.Forms.MessageBox]::Show("Clipboard empty.","Import","OK","Information") | Out-Null
            return
        }
        try {
            $parsed = $text | ConvertFrom-Json -Depth 80
        } catch {
            [Windows.Forms.MessageBox]::Show("Invalid JSON in clipboard.","Import Error","OK","Error") | Out-Null
            return
        }

        if ($Selected -and $Question.ComplexKind -eq 'ObjectArray') {
            if ($list.SelectedIndex -lt 0) {
                [Windows.Forms.MessageBox]::Show("Select an item first.","Import","OK","Information")|Out-Null
                return
            }
        }

        if ($Question.ComplexKind -eq 'ObjectArray') {
            $newArray = @()
            if ($parsed -is [System.Collections.IEnumerable] -and $parsed -isnot [string]) {
                foreach ($item in $parsed) { $newArray += $item }
            } elseif ($parsed -is [pscustomobject] -and $parsed.PSObject.Properties.Count -eq 1) {
                foreach ($p in $parsed.PSObject.Properties) {
                    if ($p.Value -is [System.Collections.IEnumerable] -and $p.Value -isnot [string]) {
                        foreach ($item in $p.Value) { $newArray += $item }
                    }
                }
            } else {
                [Windows.Forms.MessageBox]::Show("JSON not recognized as array of objects.","Import","OK","Warning")|Out-Null
                return
            }

            if ($Selected) {
                $idx=$list.SelectedIndex
                if ($newArray.Count -gt 0) {
                    $h = Convert-ItemToHashtable $newArray[0]
                    Normalize-ItemAgainstSchema -Item $h -SchemaLookup $schemaLookup | Out-Null
                    $workingItems[$idx] = (Materialize-Hashtable -Hash $h)
                }
            } else {
                $workingItems.Clear()
                foreach ($n in $newArray) {
                    $h=Convert-ItemToHashtable $n
                    Normalize-ItemAgainstSchema -Item $h -SchemaLookup $schemaLookup | Out-Null
                    [void]$workingItems.Add((Materialize-Hashtable -Hash $h))
                }
            }
        } else {
            $newMap=[ordered]@{}
            if ($parsed -is [pscustomobject]) {
                foreach ($p in $parsed.PSObject.Properties) { $newMap[$p.Name]=$p.Value }
            } elseif ($parsed -is [hashtable]) {
                foreach ($k in $parsed.Keys) { $newMap[$k]=$parsed[$k] }
            } else {
                [Windows.Forms.MessageBox]::Show("JSON not recognized as object map.","Import","OK","Warning")|Out-Null
                return
            }
            if ($Selected) {
                if ($list.SelectedIndex -lt 0) { return }
                $selectedKey=$list.SelectedItem -replace '\s\*INVALID\*$',''
                $firstKey = ($newMap.Keys | Select-Object -First 1)
                if ($firstKey) {
                    $h=Convert-ItemToHashtable $newMap[$firstKey]
                    Normalize-ItemAgainstSchema -Item $h -SchemaLookup $schemaLookup | Out-Null
                    $workingMap[$selectedKey] = (Materialize-Hashtable -Hash $h)
                }
            } else {
                $workingMap.Clear()
                foreach ($k in $newMap.Keys) {
                    $h=Convert-ItemToHashtable $newMap[$k]
                    Normalize-ItemAgainstSchema -Item $h -SchemaLookup $schemaLookup | Out-Null
                    $workingMap[$k]=(Materialize-Hashtable -Hash $h)
                }
            }
        }

        Refresh-List
        if ($list.Items.Count -gt 0) { $list.SelectedIndex = 0 }
        Load-SelectedObjectToGrid
        Log-And-Telemetry -Action "complex_import" -Message "Import successful" -Data @{ code=$Question.Code; selected=$Selected.IsPresent }
    }

    $btnExportSel.Add_Click({ Export-Collection -Selected })
    $btnImport.Add_Click({ Import-Collection -Selected })
    $btnExportAll.Add_Click({ Export-Collection })
    $btnImportAll.Add_Click({ Import-Collection })

    # Diffère le commit après fin d'édition pour éviter réentrance interne DataGridView
    $grid.Add_CellEndEdit({
        param($s,$e)
        if ($list.Tag -and $list.Tag.ContainsKey('Closing') -and $list.Tag.Closing) { return }
        # Validation immédiate PossibleValues avant commit différé
        try {
            $row = $grid.Rows[$e.RowIndex]
            $prop = $row.Cells[0].Value
            if ($prop -and $schemaLookup.ContainsKey($prop)) {
                $meta = $schemaLookup[$prop]
                if ($meta.PSObject.Properties.Name -contains 'PossibleValues' -and $meta.PossibleValues -and $row.Cells[1].ReadOnly -ne $true) {
                    $entered = "$($row.Cells[1].Value)"
                    if ($meta.Type -eq 'Array') {
                        $elements = @($entered -split ';' | Where-Object { $_ })
                        foreach ($el in $elements) {
                            if ($meta.PossibleValues -notcontains $el) {
                                [System.Windows.Forms.MessageBox]::Show("Value '$el' not allowed for $prop.","Invalid Value","OK","Warning") | Out-Null
                                $row.Cells[1].Value = ''
                                break
                            }
                        }
                    } else {
                        if ($entered -and ($meta.PossibleValues -notcontains $entered)) {
                            [System.Windows.Forms.MessageBox]::Show("Value '$entered' not allowed for $prop.","Invalid Value","OK","Warning") | Out-Null
                            $row.Cells[1].Value = ''
                        }
                    }
                }
                # Mise à jour styling mandatory (sans attendre commit)
                if ($meta.Required -and $row.Cells[0].Tag -ne 'INACTIVE') {
                    $valNow = "$( $row.Cells[1].Value )"
                    if ([string]::IsNullOrWhiteSpace($valNow) -or $valNow -match 'UNCONFIGUREDENTRY') {
                        $row.Cells[1].Style.BackColor = [System.Drawing.Color]::FromArgb(255,220,220)
                        $row.Cells[1].Style.ForeColor = [System.Drawing.Color]::DarkRed
                    } else {
                        $row.Cells[1].Style.BackColor = [System.Drawing.Color]::White
                        $row.Cells[1].Style.ForeColor = [System.Drawing.Color]::Black
                    }
                }
            }
        } catch { }
        # Utilise planification différée pour éviter réentrance interne
        Schedule-CommitGridEdits
    })

    $grid.Add_CellEnter({
        param($s,$e)
        if ($e.RowIndex -lt 0) { return }
        $prop = $grid.Rows[$e.RowIndex].Cells[0].Value
        if (-not $prop) { return }
        if ($schemaLookup.ContainsKey($prop)) {
            $txtDesc.Clear()
            $meta = $schemaLookup[$prop]
            $txtDesc.SelectionFont = New-Object System.Drawing.Font('Consolas',10,[System.Drawing.FontStyle]::Bold)
            $txtDesc.AppendText("$prop`r`n")
            $txtDesc.SelectionFont = New-Object System.Drawing.Font('Consolas',9)
            if ($meta.Description) { $txtDesc.AppendText("Description: $($meta.Description)`r`n") }
            if ($meta.Type) { $txtDesc.AppendText("Type: $($meta.Type)`r`n") }
            if ($meta.Required) { $txtDesc.AppendText("Required: $($meta.Required)`r`n") }
            if ($meta.Keys -contains 'PossibleValues' -and $meta.PossibleValues) {
                $txtDesc.AppendText("PossibleValues: " + ($meta.PossibleValues -join ', ') + "`r`n")
            }
        } else {
            $txtDesc.Clear()
            $txtDesc.AppendText("$prop`r`n(no schema metadata)")
        }
    })

    $btnOK.Add_Click({
        Commit-GridEdits
        # Final validation
        $errors = @()
        if ($Question.ComplexKind -eq 'ObjectArray') {
            for ($i=0;$i -lt $workingItems.Count;$i++) {
                $h=Convert-ItemToHashtable $workingItems[$i]
                Normalize-ItemAgainstSchema -Item $h -SchemaLookup $schemaLookup | Out-Null
                $res=Validate-ComplexEntry -SchemaLookup $schemaLookup -Entry $h
                if (-not $res.IsValid) { $errors += "Item #$i : $($res.Message)" }
            }
        } else {
            foreach ($k in $workingMap.Keys) {
                $h=Convert-ItemToHashtable $workingMap[$k]
                Normalize-ItemAgainstSchema -Item $h -SchemaLookup $schemaLookup | Out-Null
                $res=Validate-ComplexEntry -SchemaLookup $schemaLookup -Entry $h
                if (-not $res.IsValid) { $errors += "Key '$k' : $($res.Message)" }
            }
        }
        if ($errors.Count -gt 0) {
            $msg = "Validation failed:`r`n`r`n" + ($errors -join "`r`n") + "`r`n`r`nClose editor WITHOUT saving changes?`r`nYes = Close (discard), No = Continue editing"
            $resp = [System.Windows.Forms.MessageBox]::Show($msg,'Validation Failed',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)
            Log-And-Telemetry -Action "complex_validation_failed" -Message "Validation errors" -Data @{ code=$Question.Code; errors=$errors.Count; response=$resp }
            if ($resp -eq [System.Windows.Forms.DialogResult]::Yes) {
                $dlg.Tag='CANCEL'
                $dlg.Close()
            }
            return
        }

        # Commit back to question
        if ($Question.ComplexKind -eq 'ObjectArray') {
            $Question.ComplexItems.Clear()
            foreach ($it in $workingItems) { $Question.ComplexItems.Add($it) | Out-Null }
        } else {
            $Question.ComplexMap.Clear()
            foreach ($k in $workingMap.Keys) { $Question.ComplexMap[$k] = $workingMap[$k] }
        }

        $dlg.Tag = 'OK'
        $dlg.Close()
        Log-And-Telemetry -Action "complex_editor_ok" -Message "Complex edit committed" -Data @{ code=$Question.Code; kind=$Question.ComplexKind }
    })
    $btnCancel.Add_Click({
    if ($list.Tag) { $list.Tag.Closing = $true }
        $dlg.Tag = 'CANCEL'
        $dlg.Close()
        Log-And-Telemetry -Action "complex_editor_cancel" -Message "Cancelled" -Data @{ code=$Question.Code }
    })

    # Initial populate
    Refresh-List
    if ($list.Items.Count -gt 0) {
        $list.SelectedIndex=0
        $list.Tag.LastIndex = 0
    }

    [void]$dlg.ShowDialog($Global:AppState.MainForm)

    if ($dlg.Tag -ne 'OK') { return $null }

    if ($Question.ComplexKind -eq 'ObjectArray') {
        return @($Question.ComplexItems)
    } else {
        $ht=[ordered]@{}
        foreach ($k in $Question.ComplexMap.Keys) { $ht[$k]=$Question.ComplexMap[$k] }
        return [pscustomobject]$ht
    }
}