Param ()

$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Creating Scheduled Task
Write-Host "Schedule Task Creation for Microsoft Exchange Security collector Auto-Updater ..."

$DailyHour = Read-Host -Prompt "At which hour the Auto-Updater can be executed each day ? (format : hh:mmAM or hh:mmPM)"
$validated = $false
while (-not $validated)
{
    if ($DailyHour -notmatch "^[0-9]{1,2}:[0-9]{1,2}(AM|PM)$")
    {
        Write-Host "Value $DailyHour not accepted. Retry"
        $DailyHour = Read-Host -Prompt "At which hour the Auto-Updater can be executed each day ? (format : hh:mmAM or hh:mmPM)"
    }
    else  { $validated = $true }
}

$TaskUserAccount = Read-Host -Prompt "What is the account (in UPN format svc@contoso.com) used to launch the instance $Instance ?"
$TaskUserPass = Read-Host -Prompt "What is the Password of the user $TaskUserAccount used to launch the instance $Instance ?" -AsSecureString
$PwdPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($TaskUserPass)
$PlainTextPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto($PwdPointer)
[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($PwdPointer)

$scriptExecute = $scriptFolder + "\Updater.ps1"

$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "$scriptExecute"
$trigger = New-ScheduledTaskTrigger -Daily -At $DailyHour
$STSet = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 23) -MultipleInstances IgnoreNew -RestartCount 5 -RestartInterval (New-TimeSpan -Hours 1)
Register-ScheduledTask -TaskName "ESI - Exchange Security Configuration Collector - Auto-Update" -Trigger $trigger -User $TaskUserAccount -Password $PlainTextPassword -Action $action -Settings $STSet

Read-Host -Prompt "Press any key to continue ..."